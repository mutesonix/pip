// pip. — background · by SUNN. (Trithaset Chaimongkol)
importScripts('core.js');

const BG_BUILD = '1.0.0';
const SETUP_PORT = 17345;   // pip. Setup listens here while it waits for the extension

// Alt+P: float the video on this tab, or bring it back
chrome.commands.onCommand.addListener(async (cmd, tab) => {
  if (cmd !== 'toggle-pip') return;
  const t = tab || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (!t) return;
  const r = await PIP.toggle(t.id);
  if (r && r.err === 'novideo') flash(t.id, '—');
});

// which tab is floating right now (the popup can control it from any tab)
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.type === 'pip:float' && sender.tab) {
    const tabId = sender.tab.id;
    if (msg.on) {
      chrome.storage.session.set({ floating: { tabId, frameId: sender.frameId, site: msg.site, title: msg.title || sender.tab.title, w: msg.w, h: msg.h, at: Date.now() } });
      chrome.action.setBadgeText({ tabId, text: 'PIP' });
      chrome.action.setBadgeBackgroundColor({ tabId, color: '#D71921' });
    } else {
      chrome.storage.session.get('floating', ({ floating }) => {
        if (floating && floating.tabId === tabId) chrome.storage.session.remove('floating');
      });
      chrome.action.setBadgeText({ tabId, text: '' });
    }
  } else if (msg.type === 'build') {
    reply({ build: BG_BUILD });
  }
});
chrome.tabs.onRemoved.addListener(tabId => {
  chrome.storage.session.get('floating', ({ floating }) => {
    if (floating && floating.tabId === tabId) chrome.storage.session.remove('floating');
  });
});

function flash(tabId, text) {
  chrome.action.setBadgeBackgroundColor({ tabId, color: '#444' });
  chrome.action.setBadgeText({ tabId, text });
  setTimeout(() => chrome.action.setBadgeText({ tabId, text: '' }), 1400);
}

// Setup re-copies the files on update; an unpacked extension keeps running the old ones until it
// reloads, so compare the version on disk with the running one now and then
async function checkDisk() {
  try {
    const m = await (await fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' })).json();
    if (m.version && m.version !== chrome.runtime.getManifest().version) chrome.runtime.reload();
  } catch {}
}
chrome.alarms.create('disk', { periodInMinutes: 30 });
chrome.alarms.create('upd', { periodInMinutes: 360, delayInMinutes: 1 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'disk') checkDisk(); if (a.name === 'upd') checkUpdate(); });
chrome.runtime.onStartup.addListener(() => { checkDisk(); checkUpdate(); });

// a newer release on GitHub: the popup shows a "Get it" bar (running the new Setup replaces the files)
const REPO = 'mutesonix/pip';
const newer = (a, b) => { const x = a.split('.').map(Number), y = b.split('.').map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
async function checkUpdate() {
  try {
    const r = await fetch(`https://api.github.com/repos/${REPO}/releases/latest`, { cache: 'no-store' });
    if (!r.ok) return;
    const j = await r.json();
    const v = String(j.tag_name || '').replace(/^v/, '');
    const cur = chrome.runtime.getManifest().version;
    await chrome.storage.local.set({ upd: v && newer(v, cur) ? { v, url: `https://github.com/${REPO}/releases/latest`, at: Date.now() } : null });
  } catch {}
}

// say hello to pip. Setup (if it's open) so it can tick "Connected"
async function hello(reason) {
  for (let i = 0; i < 3; i++) {
    try {
      await fetch(`http://127.0.0.1:${SETUP_PORT}/pip-hello?id=${chrome.runtime.id}&v=${chrome.runtime.getManifest().version}&r=${reason}`, { mode: 'no-cors', cache: 'no-store' });
      return;
    } catch { await new Promise(r => setTimeout(r, 1500)); }
  }
}

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  hello(reason);
  checkUpdate();
  // the supported sites that were already open get pip. without a reload
  const m = chrome.runtime.getManifest();
  const tabs = await chrome.tabs.query({ url: m.content_scripts[0].matches });
  for (const t of tabs) if (!t.discarded) PIP.inject(t.id);
});
