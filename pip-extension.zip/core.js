// pip. — talking to the video in a tab, shared by the popup and the background · by SUNN.
// Toggling must start from a click or a key press (the browser only opens a floating window for a
// real gesture), so the popup calls these directly instead of going through the background.
const PIP = (() => {
  const run = (tabId, opts) => chrome.scripting.executeScript({ target: { tabId, ...(opts.frameIds ? { frameIds: opts.frameIds } : { allFrames: true }) }, ...opts.call });

  async function inject(tabId) {
    try { await run(tabId, { call: { files: ['pip.js'] } }); } catch {}
  }

  // the state of the best video in every frame of the tab, best first
  async function frames(tabId) {
    let res = [];
    try { res = await run(tabId, { call: { func: () => window.__pip ? window.__pip.state() : null } }); } catch { return []; }
    return res.filter(r => r.result && r.result.has).map(r => ({ frameId: r.frameId, ...r.result }))
      .sort((a, b) => b.score - a.score);
  }

  async function look(tabId) {
    let f = await frames(tabId);
    if (!f.length) { await inject(tabId); f = await frames(tabId); }
    return f[0] || null;
  }

  async function call(tabId, frameId, name, ...args) {
    try {
      const [r] = await run(tabId, { frameIds: [frameId], call: { func: (n, a) => window.__pip ? window.__pip[n](...a) : null, args: [name, args] } });
      return r && r.result;
    } catch (e) { return { ok: false, err: 'blocked', msg: String(e.message || e) }; }
  }

  async function toggle(tabId) {
    const v = await look(tabId);
    if (!v) return { ok: false, err: 'novideo' };
    return call(tabId, v.frameId, 'toggle');
  }

  // Netflix crashes its own player if the video's time is set from outside; ask its player to seek
  function netflixSeek(d) {
    try {
      const vp = netflix.appContext.state.playerApp.getAPI().videoPlayer;
      const ids = vp.getAllPlayerSessionIds();
      const id = ids.find(i => /^watch/.test(i)) || ids[ids.length - 1];
      const p = vp.getVideoPlayerBySessionId(id);
      p.seek(Math.max(0, p.getCurrentTime() + d * 1000));
      return true;
    } catch { return false; }
  }
  async function seek(tabId, v, d) {
    if (v.site === 'NETFLIX') {
      try {
        const [r] = await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, world: 'MAIN', func: netflixSeek, args: [d] });
        return r && r.result;
      } catch { return false; }
    }
    return call(tabId, v.frameId, 'seek', d);
  }

  return { inject, frames, look, call, toggle, seek };
})();
