// pip. — finds the main video on the page and floats it · by SUNN. (Trithaset Chaimongkol)
// Runs in every frame of the supported streaming sites, and on any other site once the popup or
// Alt+P injects it. The video stays the site's own element (DRM untouched): we only lift the
// site's "no picture-in-picture" flag and ask the browser for its standard floating window.
(() => {
  if (window.__pip) return;

  const host = location.hostname;
  const SITES = [
    [/(^|\.)netflix\.com$/, 'NETFLIX'],
    [/(^|\.)(hbo)?max\.com$/, 'HBO MAX'],
    [/(^|\.)primevideo\.com$|(^|\.)amazon\./, 'PRIME VIDEO'],
    [/(^|\.)disneyplus\.com$|(^|\.)hotstar\.com$/, 'DISNEY+'],
    [/^tv\.apple\.com$/, 'APPLE TV'],
    [/(^|\.)youtube\.com$/, 'YOUTUBE'],
    [/(^|\.)viu\.com$/, 'VIU'],
    [/(^|\.)iq\.com$/, 'IQIYI'],
    [/(^|\.)wetv\.vip$/, 'WETV'],
    [/(^|\.)bilibili\.tv$/, 'BILIBILI'],
    [/(^|\.)twitch\.tv$/, 'TWITCH'],
    [/(^|\.)hulu\.com$/, 'HULU'],
    [/(^|\.)paramountplus\.com$/, 'PARAMOUNT+'],
    [/(^|\.)crunchyroll\.com$/, 'CRUNCHYROLL'],
    [/(^|\.)trueid\.net$/, 'TRUEID'],
    [/(^|\.)monomax\.me$/, 'MONOMAX'],
  ];
  const site = (SITES.find(([re]) => re.test(host)) || [, host.replace(/^www\./, '').toUpperCase()])[1];
  const KNOWN = SITES.some(([re]) => re.test(host));
  const IS_NETFLIX = site === 'NETFLIX';

  // ---------- picking the video ----------
  // every <video>, including ones inside open shadow roots (some players hide theirs there)
  function allVideos() {
    const out = [...document.querySelectorAll('video')];
    if (out.length) return out;
    const walk = root => {
      for (const el of root.querySelectorAll('*')) {
        if (el.shadowRoot) {
          out.push(...el.shadowRoot.querySelectorAll('video'));
          walk(el.shadowRoot);
        }
      }
    };
    walk(document);
    return out;
  }
  function score(v) {
    if (!v.isConnected || (!v.currentSrc && !v.srcObject && v.readyState === 0)) return 0;
    const r = v.getBoundingClientRect();
    const w = Math.max(0, Math.min(r.right, innerWidth) - Math.max(r.left, 0));
    const h = Math.max(0, Math.min(r.bottom, innerHeight) - Math.max(r.top, 0));
    let s = w * h;
    if (document.pictureInPictureElement === v) s += 1e12;          // already floating: always the one
    if (!v.paused && !v.ended) s += 1e9;                               // playing beats bigger-but-idle (trailers, ads)
    if (v.readyState >= 2) s += 1e6;
    if (isFinite(v.duration) && v.duration > 90) s += 1e5;
    if (v.muted && v.paused) s *= .5;                                  // hover previews
    return s;
  }
  function best() {
    if (dp && dp.v) return { v: dp.v, s: 1e13 };   // floating in our own window
    let top = null, ts = 0;
    for (const v of allVideos()) {
      const s = score(v);
      if (s > ts) { top = v; ts = s; }
    }
    return top ? { v: top, s: ts } : null;
  }

  // sites set disablePictureInPicture (and some set it again later): lift it on the video we float
  const guard = new MutationObserver(recs => {
    for (const r of recs) if (r.target.hasAttribute('disablepictureinpicture')) unlock(r.target);
  });
  function unlock(v) {
    v.disablePictureInPicture = false;
    v.removeAttribute('disablepictureinpicture');
    if (!v.__pipGuard) { v.__pipGuard = true; guard.observe(v, { attributes: true, attributeFilter: ['disablepictureinpicture'] }); }
  }

  // ---------- titles ----------
  const TITLE_SEL = [
    '[data-uia="video-title"]',                                     // Netflix
    '[data-testid="player-ux-asset-title"]', '[class*="PlayerTitle"]', // HBO Max
    '.atvwebplayersdk-title-text',                                  // Prime Video
    '.title-field', '[data-testid="title-field"]',                  // Disney+
  ];
  const SUB_SEL = ['.atvwebplayersdk-subtitle-text', '[data-testid="player-ux-asset-subtitle"]', '.subtitle-field'];
  const text = sels => {
    for (const s of sels) {
      const el = document.querySelector(s);
      const t = el && el.textContent.replace(/\s+/g, ' ').trim();
      if (t) return t;
    }
    return '';
  };
  function title() {
    let t = text(TITLE_SEL);
    if (IS_NETFLIX) {   // Netflix: <h4>Show</h4><span>S1:E2</span><span>Episode</span>
      const el = document.querySelector('[data-uia="video-title"]');
      if (el) t = [...el.children].map(c => c.textContent.trim()).filter(Boolean).join(' · ') || t;
    }
    const sub = text(SUB_SEL);
    if (t && sub && !t.includes(sub)) t += ' · ' + sub;
    if (!t) t = document.title.replace(/\s*[|\-–—]\s*(Netflix|HBO Max|Max|Prime Video|Amazon\.com.*|Disney\+.*|YouTube|Twitch)\s*$/i, '').trim();
    return t;
  }

  // ---------- talking to the page's own player (auto.js, page world) ----------
  let reqN = 0;
  const waiting = new Map();
  addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.__pip !== 'res') return;
    const f = waiting.get(e.data.id);
    if (f) { waiting.delete(e.data.id); f(e.data.res); }
  });
  function bridge(cmd, arg) {
    return new Promise(res => {
      const id = 'p' + (++reqN) + Math.random().toString(36).slice(2, 6);
      waiting.set(id, res);
      window.postMessage({ __pip: 'req', id, cmd, arg }, '*');
      setTimeout(() => { if (waiting.delete(id)) res(null); }, 1500);
    });
  }

  // ---------- floating window with subtitles (Document PiP) ----------
  let dp = null, docMode = true, subSize = 100, subsOn = true;
  const canDoc = () => docMode && window === window.top && 'documentPictureInPicture' in window && !!window.__pipDoc;
  async function openDoc(v) {
    dp = { v, opening: true };
    try {
      const h = await window.__pipDoc.open(v, {
        site, title: title(), size: subSize, subsOn, isNetflix: IS_NETFLIX, bridge,
        onSize: n => { subSize = n; try { chrome.storage.local.set({ subSize: n }); } catch {} },
        onSubs: on => { subsOn = on; try { chrome.storage.local.set({ subsOn: on }); } catch {} },
        onClose: () => { dp = null; report(false, v); },
      });
      dp = h;
      hideBtn();
      report(true, v);
    } catch (e) { dp = null; throw e; }
  }

  // ---------- actions ----------
  function state() {
    const b = best();
    const pip = dp ? dp.v : document.pictureInPictureElement;
    if (!b) return { has: false, pip: !!pip, site, known: KNOWN, top: window === window.top };
    const v = b.v;
    return {
      has: true, score: b.s, site, known: KNOWN, top: window === window.top,
      pip: pip === v, pipOther: !!pip && pip !== v,
      title: window === window.top ? title() : '',
      w: v.videoWidth, h: v.videoHeight,
      t: v.currentTime, d: isFinite(v.duration) ? v.duration : 0,
      paused: v.paused, rate: v.playbackRate, muted: v.muted,
      supported: 'pictureInPictureEnabled' in document && document.pictureInPictureEnabled !== false,
    };
  }

  async function toggle() {
    try {
      if (dp && dp.close) { dp.close(); return { ok: true, pip: false }; }
      if (document.pictureInPictureElement) { await document.exitPictureInPicture(); return { ok: true, pip: false }; }
      const b = best();
      if (!b) return { ok: false, err: 'novideo' };
      const v = b.v;
      unlock(v);
      if (v.readyState < 1) return { ok: false, err: 'notready' };
      if (canDoc()) {
        try { await openDoc(v); return { ok: true, pip: true, subs: true }; }
        catch (e) { if (e && e.name === 'NotAllowedError') throw e; }   // anything else: fall back to the classic window
      }
      await v.requestPictureInPicture();
      return { ok: true, pip: true };
    } catch (e) {
      toast(e && e.name === 'NotAllowedError' ? 'Click the video once, then try again' : 'Can\'t float this one', true);
      return { ok: false, err: e && e.name || 'error', msg: String(e && e.message || e) };
    }
  }

  function play() {
    const b = best(); if (!b) return false;
    if (b.v.paused) b.v.play().catch(() => {}); else b.v.pause();
    return true;
  }
  function seek(d) {
    if (IS_NETFLIX) { bridge('seek', d); return true; }   // Netflix stops playback when currentTime is set directly
    const b = best(); if (!b) return false;
    const v = b.v;
    v.currentTime = Math.max(0, Math.min((v.duration || 1e9) - .5, v.currentTime + d));
    return true;
  }
  function rate(r) {
    const b = best(); if (!b) return false;
    b.v.playbackRate = r;
    return true;
  }

  // ---------- float button on the player (known sites only) ----------
  let btnOn = true;
  const FLOAT = s => `<svg viewBox="0 0 ${s} ${s}" width="100%" height="100%" aria-hidden="true">${
    (() => {   // dot-matrix frame with a solid little window in its lower-right corner
      let d = ''; const c = s / 9;
      for (let y = 0; y < 7; y++) for (let x = 0; x < 9; x++) {
        const edge = y === 0 || y === 6 || x === 0 || x === 8;
        const win = x >= 5 && x <= 7 && y >= 3 && y <= 5;
        if (!edge && !win) continue;
        const red = x === 7 && y === 5;
        d += `<circle cx="${c * (x + .5)}" cy="${c * (y + 1.5)}" r="${red ? c * .44 : win ? c * .4 : c * .26}" fill="${red ? '#E30713' : '#fff'}" opacity="${edge && !win ? .7 : 1}"/>`;
      }
      return d;
    })()}</svg>`;

  const hostEl = document.createElement('div');
  hostEl.style.cssText = 'position:fixed;z-index:2147483647;top:0;left:0;width:0;height:0';
  const root = hostEl.attachShadow({ mode: 'closed' });
  root.innerHTML = `<style>
    :host { all: initial; }
    .b { position: fixed; display: flex; align-items: center; gap: 0; height: 44px; padding: 0 11px; border-radius: 999px;
         background: rgba(0,0,0,.66); backdrop-filter: blur(14px) saturate(1.3); -webkit-backdrop-filter: blur(14px) saturate(1.3);
         border: 1px solid rgba(255,255,255,.16); color: #f4f4f4; cursor: pointer; pointer-events: auto;
         font: 700 12px/1 ui-monospace, "SF Mono", "Cascadia Mono", Consolas, monospace; letter-spacing: .14em;
         opacity: 0; transform: translateX(10px) scale(.94); transition: opacity .3s cubic-bezier(.32,.72,0,1), transform .5s cubic-bezier(.34,1.36,.64,1), background .2s, gap .4s cubic-bezier(.32,.72,0,1); }
    .b.on { opacity: 1; transform: none; }
    .b:hover { background: rgba(0,0,0,.86); gap: 9px; }
    .b:active { transform: scale(.92); }
    .i { width: 22px; height: 22px; flex: none; }
    .l { max-width: 0; overflow: hidden; white-space: nowrap; transition: max-width .45s cubic-bezier(.32,.72,0,1); }
    .b:hover .l { max-width: 80px; }
    .t { position: fixed; padding: 9px 14px; border-radius: 999px; background: rgba(0,0,0,.84); border: 1px solid rgba(255,255,255,.14);
         color: #f4f4f4; font: 600 12px/1 -apple-system, "Segoe UI", system-ui, sans-serif; white-space: nowrap; pointer-events: none;
         opacity: 0; transform: translateY(-4px); transition: opacity .3s, transform .4s cubic-bezier(.32,.72,0,1); }
    .t.on { opacity: 1; transform: none; }
    .t.err::before { content: ""; display: inline-block; width: 6px; height: 6px; border-radius: 50%; background: #E30713; margin-right: 8px; vertical-align: 1px; }
    @media (prefers-reduced-motion: reduce) { .b, .t, .l { transition-duration: .01ms !important; } }
  </style><button class="b" id="b" title="Float this video — pip. (Alt+P)"><span class="i">${FLOAT(22)}</span><span class="l">FLOAT</span></button><div class="t" id="t"></div>`;
  const btn = root.getElementById('b'), tEl = root.getElementById('t');
  let anchor = null, hideT = 0, toastT = 0;

  function mount() {
    const fs = document.fullscreenElement || document.webkitFullscreenElement;
    const parent = fs && fs.tagName !== 'VIDEO' ? fs : document.documentElement;
    if (hostEl.parentNode !== parent) parent.appendChild(hostEl);
  }
  function place() {
    if (!anchor || !anchor.isConnected) return false;
    const r = anchor.getBoundingClientRect();
    if (r.width < 240 || r.height < 135) return false;
    // right edge, vertically centred: the one spot the big players leave empty
    btn.style.top = Math.round(r.top + r.height / 2 - 22) + 'px';
    btn.style.right = Math.round(Math.max(8, innerWidth - r.right + 18)) + 'px';
    return true;
  }
  function showBtn() {
    if (!btnOn || document.pictureInPictureElement || dp) return;
    const b = best();
    if (!b || b.v.readyState < 1) return;
    anchor = b.v;
    mount();
    if (!place()) return hideBtn();
    btn.classList.add('on');
    clearTimeout(hideT);
    hideT = setTimeout(hideBtn, 2600);
  }
  function hideBtn() { btn.classList.remove('on'); }
  function toast(msg, err) {
    mount();
    const r = (anchor || (best() || {}).v || document.body).getBoundingClientRect();
    tEl.textContent = msg;
    tEl.classList.toggle('err', !!err);
    tEl.style.top = Math.round(Math.max(12, r.top + r.height / 2 + 34)) + 'px';
    tEl.style.right = Math.round(Math.max(8, innerWidth - r.right + 18)) + 'px';
    tEl.classList.add('on');
    clearTimeout(toastT);
    toastT = setTimeout(() => tEl.classList.remove('on'), 2400);
  }
  btn.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); hideBtn(); toggle(); }, true);
  ['pointerdown', 'mousedown', 'mouseup', 'dblclick'].forEach(t => btn.addEventListener(t, e => e.stopPropagation(), true));
  btn.addEventListener('mouseenter', () => clearTimeout(hideT));
  btn.addEventListener('mouseleave', () => { hideT = setTimeout(hideBtn, 1200); });

  if (KNOWN) {
    let raf = 0;
    document.addEventListener('mousemove', () => {
      if (raf) return;
      raf = requestAnimationFrame(() => { raf = 0; showBtn(); });
    }, { passive: true, capture: true });
    document.addEventListener('fullscreenchange', () => { mount(); hideBtn(); });
    addEventListener('scroll', () => { if (btn.classList.contains('on')) place() || hideBtn(); }, { passive: true, capture: true });
  }

  // ---------- tell pip. when something floats here ----------
  function report(on, v) {
    try { chrome.runtime.sendMessage({ type: 'pip:float', on, site, title: on ? title() : '', w: v && v.videoWidth, h: v && v.videoHeight }); } catch {}
  }
  document.addEventListener('enterpictureinpicture', e => { hideBtn(); report(true, e.target); }, true);
  document.addEventListener('leavepictureinpicture', e => report(false, e.target), true);

  function loadSettings() {
    try {
      chrome.storage.local.get({ button: true, auto: true, docpip: true, subSize: 100, subsOn: true }, s => {
        btnOn = s.button !== false;
        docMode = s.docpip !== false;
        subSize = +s.subSize || 100;
        subsOn = s.subsOn !== false;
        if (dp && dp.setSize) { dp.setSize(subSize); dp.setSubs(subsOn); }
        if (!btnOn) hideBtn();
        document.documentElement.setAttribute('data-pip-auto', s.auto === false ? '0' : '1');   // read by auto.js (page world)
        document.documentElement.setAttribute('data-pip-doc', canDoc() ? '1' : '0');
      });
    } catch {}
  }
  loadSettings();
  try { chrome.storage.onChanged.addListener(loadSettings); } catch {}

  // automatic float (auto.js got the browser's "enterpictureinpicture" action): open our window instead
  document.addEventListener('pip:auto', () => { if (!dp && !document.pictureInPictureElement) toggle(); });

  window.__pip = { state, toggle, play, seek, rate, toast };
})();
