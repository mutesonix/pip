// pip. — float automatically when you switch tabs · by SUNN. (Trithaset Chaimongkol)
// Runs in the page's own world: registers the Media Session "enterpictureinpicture" action, which is
// the browser's own hook for automatic picture-in-picture. Chrome decides when it fires (a playing,
// audible video on a tab you leave) and may ask you once per site. Off when the setting is off.
(() => {
  if (window.__pipAuto || !('mediaSession' in navigator)) return;
  window.__pipAuto = true;

  function pick() {
    let top = null, ts = 0;
    for (const v of document.querySelectorAll('video')) {
      if (v.paused || v.ended || v.readyState < 2) continue;
      const r = v.getBoundingClientRect(), s = r.width * r.height + (v.muted ? 0 : 1e9);
      if (s > ts) { top = v; ts = s; }
    }
    return top;
  }

  try {
    navigator.mediaSession.setActionHandler('enterpictureinpicture', async () => {
      if (document.documentElement.getAttribute('data-pip-auto') === '0' || document.pictureInPictureElement) return;
      const v = pick();
      if (!v) return;
      v.disablePictureInPicture = false;
      v.removeAttribute('disablepictureinpicture');
      try { await v.requestPictureInPicture(); } catch {}
    });
  } catch { /* browser without automatic picture-in-picture */ }
})();
