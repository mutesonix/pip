// pip. — float automatically when you switch tabs · by SUNN. (Trithaset Chaimongkol)
// Runs in the page's own world: registers the Media Session "enterpictureinpicture" action, which is
// the browser's own hook for automatic picture-in-picture. Chrome decides when it fires (a playing,
// audible video on a tab you leave) and may ask you once per site. Off when the setting is off.
(() => {
  if (window.__pipAuto || !('mediaSession' in navigator)) return;
  window.__pipAuto = true;

  function pick() {
    let top = null, ts = 0;
    for (const v of document.querySelectorAll('video')) {
      if (v.paused || v.ended || v.readyState < 2) continue;
      const r = v.getBoundingClientRect(), s = r.width * r.height + (v.muted ? 0 : 1e9);
      if (s > ts) { top = v; ts = s; }
    }
    return top;
  }

  try {
    navigator.mediaSession.setActionHandler('enterpictureinpicture', async () => {
      const de = document.documentElement;
      if (de.getAttribute('data-pip-auto') === '0' || document.pictureInPictureElement || window.documentPictureInPicture?.window) return;
      if (de.getAttribute('data-pip-doc') === '1') { document.dispatchEvent(new CustomEvent('pip:auto')); return; }   // pip.js opens the window with subtitles
      const v = pick();
      if (!v) return;
      v.disablePictureInPicture = false;
      v.removeAttribute('disablepictureinpicture');
      try { await v.requestPictureInPicture(); } catch {}
    });
  } catch { /* browser without automatic picture-in-picture */ }

  // Netflix's own player API, for pip.js in the extension's world: track lists, switching, seeking
  addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.__pip !== 'req') return;
    const { id, cmd, arg } = e.data;
    let res = null;
    try {
      const vp = netflix.appContext.state.playerApp.getAPI().videoPlayer;
      const ids = vp.getAllPlayerSessionIds();
      const p = vp.getVideoPlayerBySessionId(ids.find(i => /^watch/.test(i)) || ids[ids.length - 1]);
      if (cmd === 'tracks') {
        const ct = p.getTimedTextTrack(), ca = p.getAudioTrack();
        res = {
          text: p.getTimedTextTrackList().map(t => ({ id: t.trackId, label: (t.displayName || t.bcp47 || 'Track') + (t.rawTrackType === 'closedcaptions' ? ' [CC]' : ''), on: !!ct && ct.trackId === t.trackId })),
          audio: p.getAudioTrackList().map(t => ({ id: t.trackId, label: t.displayName || t.bcp47 || 'Audio', on: !!ca && ca.trackId === t.trackId })),
        };
      } else if (cmd === 'text') {
        const t = p.getTimedTextTrackList().find(x => x.trackId === arg);
        if (t) { p.setTimedTextTrack(t); res = true; }
      } else if (cmd === 'audio') {
        const t = p.getAudioTrackList().find(x => x.trackId === arg);
        if (t) { p.setAudioTrack(t); res = true; }
      } else if (cmd === 'seek') {
        p.seek(Math.max(0, p.getCurrentTime() + arg * 1000));
        res = true;
      }
    } catch {}
    window.postMessage({ __pip: 'res', id, res }, '*');
  });
})();
