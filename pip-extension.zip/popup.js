// pip. — popup · by SUNN. (Trithaset Chaimongkol)
const POPUP_BUILD = '1.0.0';
const $ = s => document.querySelector(s);
const SITES = ['NETFLIX', 'HBO MAX', 'PRIME VIDEO', 'DISNEY+', 'APPLE TV', 'YOUTUBE', 'VIU', 'IQIYI', 'WETV', 'TWITCH', 'ANY SITE'];
const DOTS = 36;

let tabId = null, target = null, v = null, remote = false, timer = 0, busy = false;

// ---------- small things ----------
function show(id) {
  for (const s of ['loading', 'empty', 'stage']) $('#' + s).classList.toggle('hidden', s !== id);
}
function status(text, cls) {
  const el = $('#status');
  el.className = 'status ' + (cls || '');
  el.querySelector('b').textContent = text;
}
const tc = s => {
  s = Math.max(0, Math.floor(s || 0));
  const h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60, x = s % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0');
};
const resLabel = h => !h ? '' : h >= 2000 ? '4K' : h >= 1400 ? '1440P' : h >= 1000 ? '1080P' : h >= 700 ? '720P' : h + 'P';
function hint(text, err) {
  const el = $('#hint');
  el.textContent = text || '';
  el.classList.toggle('err', !!err);
}

// dot-matrix icons for the CTA: a frame with a little window that floats out, or docks back in
function icon(back) {
  const c = 2.9, R = [];
  for (let y = 0; y < 7; y++) for (let x = 0; x < 9; x++) {
    const edge = y === 0 || y === 6 || x === 0 || x === 8;
    const win = back ? x >= 1 && x <= 4 && y >= 1 && y <= 3 : x >= 5 && x <= 7 && y >= 3 && y <= 5;
    if (!edge && !win) continue;
    const red = back ? x === 4 && y === 1 : x === 7 && y === 5;
    R.push(`<circle cx="${c * (x + .5)}" cy="${c * (y + .5)}" r="${red ? 1.25 : win ? 1.1 : .75}" fill="${red ? '#D71921' : 'currentColor'}" opacity="${edge && !win ? .55 : 1}"/>`);
  }
  return `<svg viewBox="0 0 ${c * 9} ${c * 7}" width="26" height="20">${R.join('')}</svg>`;
}

// ---------- looking for the video ----------
async function find() {
  $('#btnRefresh').classList.add('spin');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab && tab.id;
  const { floating } = await chrome.storage.session.get('floating');
  let found = tabId != null ? await PIP.look(tabId) : null;
  remote = false;
  target = tabId;
  // nothing here, but something is floating from another tab: control that one
  if ((!found || !found.pip) && floating && floating.tabId !== tabId) {
    const f = (await PIP.frames(floating.tabId).catch(() => []))[0];
    if (f && f.pip && !found) { found = f; target = floating.tabId; remote = true; }
  }
  $('#btnRefresh').classList.remove('spin');
  if (!found) return empty(tab);
  v = found;
  stage(true);
  clearInterval(timer);
  timer = setInterval(tick, 500);
}

function empty(tab) {
  clearInterval(timer);
  const url = (tab && tab.url) || '';
  const locked = /^(chrome|edge|brave|arc|about|chrome-extension|devtools|view-source):/.test(url) || /chromewebstore\.google\.com|chrome\.google\.com\/webstore/.test(url);
  $('#emptySub').innerHTML = locked
    ? 'Browsers don\'t let extensions into this page. Open a video site and try again.'
    : `Start playing something, then press <b>FLOAT</b> — or <code>${kbd}</code> right on the page.`;
  status('NO VIDEO');
  show('empty');
}

async function tick() {
  if (busy || target == null) return;
  const f = await PIP.frames(target).catch(() => []);
  const n = f.find(x => x.frameId === v.frameId) || f[0];
  if (!n) { if (!remote) find(); return; }
  v = n;
  stage(false);
}

// ---------- drawing ----------
function stage(first) {
  show('stage');
  const sc = $('#screen');
  sc.classList.add('ready');
  sc.classList.toggle('floating', !!v.pip);
  sc.classList.toggle('paused', !!v.paused);
  $('#winSite').textContent = v.site;
  $('#vBadge').textContent = v.site;
  $('#vRes').textContent = resLabel(v.h);
  $('#vTime').textContent = v.d ? tc(v.t) : 'LIVE';
  if (first || $('#vTitle').textContent !== v.title) $('#vTitle').textContent = v.title || '';
  $('#vSub').textContent = remote ? 'Floating from another tab' : v.w ? `${v.w} × ${v.h}` : '';
  $('#vNote').textContent = v.d ? '−' + tc(v.d - v.t) : '';

  const bar = $('#bar');
  if (!bar.children.length) bar.innerHTML = Array.from({ length: DOTS }, () => '<i></i>').join('');
  bar.classList.toggle('live', !v.d);
  if (v.d) {
    const f = Math.min(DOTS - 1, Math.floor(v.t / v.d * DOTS));
    [...bar.children].forEach((d, i) => d.className = i < f ? 'f' : i === f ? 'h' : '');
  }

  $('#icoPlay').classList.toggle('hidden', !v.paused);
  $('#icoPause').classList.toggle('hidden', !!v.paused);
  $('#btnBack').disabled = $('#btnFwd').disabled = !v.d;
  $('#segRate').querySelectorAll('button').forEach(b => b.classList.toggle('on', Math.abs(+b.dataset.v - v.rate) < .01));
  placePill();

  const cta = $('#btnFloat');
  cta.classList.toggle('back', !!v.pip);
  $('#ctaLabel').textContent = v.pip ? 'BRING BACK' : 'FLOAT';
  $('#ctaIco').innerHTML = icon(!!v.pip);
  if (v.pip) status('FLOATING', 'live');
  else status(v.paused ? 'PAUSED' : 'PLAYING', 'ok');
  if (!$('#hint').classList.contains('err')) hint(v.pip ? 'Drag it anywhere · resize from a corner' : `or press ${kbd} on the page`);
}

function placePill() {
  const seg = $('#segRate'), on = seg.querySelector('button.on'), pill = seg.querySelector('.pill');
  if (!on) { pill.style.width = '0'; return; }
  pill.style.width = on.offsetWidth + 'px';
  pill.style.transform = `translateX(${on.offsetLeft - 3}px)`;
}

// ---------- actions ----------
$('#btnFloat').onclick = async () => {
  if (busy || target == null) return;
  busy = true;
  $('#btnFloat').classList.add('busy');
  hint('');
  // must run straight from this click: the browser only floats a video for a real gesture
  const r = v ? await PIP.call(target, v.frameId, 'toggle') : await PIP.toggle(target);
  busy = false;
  $('#btnFloat').classList.remove('busy');
  if (r && !r.ok) {
    const why = { novideo: 'No video found on this tab.', notready: 'The video is still loading — press play first.', NotAllowedError: 'The browser blocked it. Click the video once, then try again.', blocked: 'This page doesn\'t allow extensions.' }[r.err];
    hint(why || 'Couldn\'t float this video' + (r.msg ? ': ' + r.msg : '.'), true);
  } else {
    setTimeout(() => hint(''), 0);
    if (r && r.pip && !remote) setTimeout(() => window.close(), 650);   // out of the way, the window is up
  }
  tick();
};
$('#btnPlay').onclick = async () => { if (v) { await PIP.call(target, v.frameId, 'play'); tick(); } };
$('#btnBack').onclick = async () => { if (v) { await PIP.seek(target, v, -10); tick(); } };
$('#btnFwd').onclick = async () => { if (v) { await PIP.seek(target, v, 10); tick(); } };
$('#segRate').onclick = async e => {
  const b = e.target.closest('button');
  if (!b || !v) return;
  $('#segRate').querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b));
  placePill();
  await PIP.call(target, v.frameId, 'rate', +b.dataset.v);
  tick();
};
$('#btnRefresh').onclick = () => { hint(''); find(); };

// ---------- settings ----------
function openSheet(on) {
  document.body.classList.toggle('sheet-open', on);
  $('#btnSettings').classList.toggle('on', on);
}
$('#btnSettings').onclick = () => openSheet(!document.body.classList.contains('sheet-open'));
$('#btnDone').onclick = () => openSheet(false);
$('#scrim').onclick = () => openSheet(false);
chrome.storage.local.get({ auto: true, button: true }, s => {
  $('#optAuto').checked = s.auto !== false;
  $('#optButton').checked = s.button !== false;
});
$('#optAuto').onchange = e => chrome.storage.local.set({ auto: e.target.checked });
$('#optButton').onchange = e => chrome.storage.local.set({ button: e.target.checked });
$('#btnKeys').onclick = () => {
  const url = /Edg\//.test(navigator.userAgent) ? 'edge://extensions/shortcuts' : 'chrome://extensions/shortcuts';
  chrome.tabs.create({ url });
};

// ---------- boot ----------
let kbd = 'Alt+P';
async function boot() {
  $('#sites').innerHTML = SITES.map((s, i) => `<span class="${i < 3 ? 'top' : ''}" style="--i:${i}">${s}</span>`).join('');
  $('#ver').firstChild.textContent = 'v' + chrome.runtime.getManifest().version + ' · by ';
  try {
    const c = (await chrome.commands.getAll()).find(x => x.name === 'toggle-pip');
    kbd = c && c.shortcut ? c.shortcut : 'not set';
  } catch {}
  $('#kbd2').textContent = kbd;
  // files on disk were updated but the background is still the old one: restart once
  chrome.runtime.sendMessage({ type: 'build' }).then(r => {
    if (r && r.build !== POPUP_BUILD) chrome.runtime.reload();
  }).catch(() => {});
  chrome.storage.local.get('upd', ({ upd }) => {
    if (!upd || !upd.v) return;
    $('#updText').innerHTML = `<b>v${upd.v}</b> is out · new Setup inside`;
    $('#btnUpd').onclick = () => chrome.tabs.create({ url: upd.url });
    $('#updBar').classList.remove('hidden');
  });
  find();
}
window.addEventListener('unload', () => clearInterval(timer));
boot();
