// pip. — the floating window with subtitles · by SUNN. (Trithaset Chaimongkol)
// Uses Document Picture-in-Picture: the site's own <video> element is moved into a small always-on-top
// window we draw ourselves, so subtitles, a track menu and controls can sit on top of it. The stream
// isn't touched (same element, same player, same DRM session) and the video goes back when it closes.
// Subtitles are copied as text from what the site draws on the tab, or read from the video's own
// text tracks on sites that use them.
(() => {
  if (window.__pipDoc) return;

  // where each site draws its subtitles (text is read from here while the window is open)
  const CAPTIONS = [
    '.player-timedtext',                                   // Netflix
    '.atvwebplayersdk-captions-text',                      // Prime Video
    '[data-testid="CueBoxContainer"]', '[class*="CaptionWindow"]', '[class*="caption-window"]', // HBO Max
    '.dss-subtitle-renderer-cue-window', '.hive-subtitle-renderer-cue-window', // Disney+
    '.ytp-caption-window-container',                       // YouTube
    '[class*="subtitle-text"]', '[class*="subtitles-text"]', '[class*="SubtitleText"]', // Viu, iQIYI, WeTV & co
  ];

  const esc = s => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const tc = s => {
    s = Math.max(0, Math.floor(s || 0));
    const h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60, x = s % 60;
    return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0');
  };

  const CSS = `
    :root { color-scheme: dark; --red: #D71921; --fg: #f4f4f4; --ease: cubic-bezier(.32,.72,0,1); --spring: cubic-bezier(.34,1.36,.64,1); }
    * { box-sizing: border-box; }
    html, body { margin: 0; height: 100%; background: #000; overflow: hidden; color: var(--fg);
      font: 13px/1.3 -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", "Leelawadee UI", "Thonburi", system-ui, sans-serif; }
    button { font: inherit; color: inherit; background: none; border: 0; padding: 0; cursor: pointer; }
    #stage { position: absolute; inset: 0; }
    #stage video { position: absolute !important; inset: 0 !important; width: 100% !important; height: 100% !important; max-width: none !important; max-height: none !important;
      object-fit: contain !important; transform: none !important; margin: 0 !important; background: #000; }
    #stage video::cue { opacity: 0; }   /* we draw the cues ourselves */

    #subs { position: absolute; left: 4%; right: 4%; bottom: calc(6% + var(--lift, 0px)); display: flex; flex-direction: column; align-items: center; gap: .12em;
      text-align: center; pointer-events: none; font-size: calc(var(--s, 1) * clamp(12px, 6.2vh, 44px)); font-weight: 600; line-height: 1.22;
      transition: bottom .35s var(--ease); }
    #subs span { background: rgba(0,0,0,var(--bg, .62)); padding: .06em .38em .1em; border-radius: .22em; text-shadow: 0 1px 2px rgba(0,0,0,.9), 0 0 6px rgba(0,0,0,.6);
      white-space: pre-wrap; max-width: 100%; }
    #subs.off { display: none; }
    body.ui #subs { --lift: 52px; }

    #ui { position: absolute; inset: 0; opacity: 0; transition: opacity .3s var(--ease); pointer-events: none; }
    body.ui #ui { opacity: 1; pointer-events: auto; }
    #ui::before { content: ""; position: absolute; left: 0; right: 0; bottom: 0; height: 120px; background: linear-gradient(transparent, rgba(0,0,0,.78)); pointer-events: none; }
    #top { position: absolute; left: 10px; right: 10px; top: 8px; display: flex; justify-content: space-between; align-items: center; gap: 8px; }
    .wm { font: 800 15px/1 ui-monospace, "SF Mono", Consolas, monospace; letter-spacing: .02em; display: inline-flex; align-items: baseline; text-shadow: 0 1px 3px #000; }
    .wm i { width: 4px; height: 4px; border-radius: 50%; background: var(--red); margin-left: 2px; display: inline-block; }
    #ttl { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12px; color: rgba(255,255,255,.8); text-shadow: 0 1px 3px #000; }
    #bar { position: absolute; left: 8px; right: 8px; bottom: 8px; display: flex; align-items: center; gap: 4px; }
    .b { height: 34px; min-width: 34px; padding: 0 8px; border-radius: 999px; display: inline-grid; place-items: center; background: rgba(255,255,255,.08);
      transition: background .2s, transform .3s var(--spring); position: relative; }
    .b:hover { background: rgba(255,255,255,.18); }
    .b:active { transform: scale(.9); }
    .b.on { background: var(--fg); color: #000; }
    .b svg { display: block; }
    .b em { font: 800 8px/1 ui-monospace, monospace; font-style: normal; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -38%); }
    .txt { font: 700 11px/1 ui-monospace, "SF Mono", Consolas, monospace; letter-spacing: .08em; }
    #time { font: 600 11px/1 ui-monospace, monospace; color: rgba(255,255,255,.75); padding: 0 6px; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .sp { flex: 1; }
    #prog { position: absolute; left: 14px; right: 14px; bottom: 48px; height: 14px; cursor: pointer; }
    #prog::before { content: ""; position: absolute; left: 0; right: 0; top: 6px; height: 3px; border-radius: 2px; background: rgba(255,255,255,.22); }
    #fill { position: absolute; left: 0; top: 6px; height: 3px; border-radius: 2px; background: var(--red); width: 0; }

    .menu { position: absolute; right: 8px; bottom: 50px; width: min(260px, calc(100% - 16px)); max-height: calc(100% - 70px); overflow-y: auto;
      background: rgba(14,14,14,.96); border: 1px solid #2c2c2c; border-radius: 14px; padding: 6px; display: none; box-shadow: 0 16px 40px rgba(0,0,0,.6); }
    .menu.open { display: block; animation: up .3s var(--ease); }
    @keyframes up { from { opacity: 0; transform: translateY(6px); } }
    .menu h4 { margin: 6px 8px 4px; font: 700 9.5px/1 ui-monospace, monospace; letter-spacing: .16em; color: #8b8b8b; text-transform: uppercase; }
    .menu button.it { display: flex; width: 100%; align-items: center; gap: 8px; padding: 8px 10px; border-radius: 9px; text-align: left; font-size: 12.5px; }
    .menu button.it:hover { background: #1c1c1c; }
    .menu button.it::before { content: ""; width: 6px; height: 6px; border-radius: 50%; background: #2c2c2c; flex: none; }
    .menu button.it.on::before { background: var(--red); }
    .menu p { margin: 6px 10px 8px; color: #8b8b8b; font-size: 11.5px; line-height: 1.45; }
    .menu .row { display: flex; align-items: center; gap: 6px; padding: 4px 6px 6px; }
    .menu .row .b { background: #1c1c1c; }
    .menu .row span { flex: 1; text-align: center; font: 700 12px/1 ui-monospace, monospace; }
    hr { border: 0; border-top: 1px solid #222; margin: 6px 4px; }
    #flash { position: absolute; left: 50%; top: 42%; transform: translate(-50%, -50%); padding: 8px 14px; border-radius: 999px; background: rgba(0,0,0,.72);
      font: 700 12px/1 ui-monospace, monospace; letter-spacing: .08em; opacity: 0; transition: opacity .25s; pointer-events: none; white-space: nowrap; }
    #flash.on { opacity: 1; }
    @media (max-width: 360px) { #time, .wide { display: none; } }
    @media (prefers-reduced-motion: reduce) { * { transition-duration: .01ms !important; animation-duration: .01ms !important; } }
  `;

  const I = {
    play: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.5v13l10.5-6.5z"/></svg>',
    pause: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><rect x="6.5" y="5" width="4" height="14" rx="1.2"/><rect x="13.5" y="5" width="4" height="14" rx="1.2"/></svg>',
    back: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12a8 8 0 1 0 2.34-5.66"/><path d="M4 4v4.5h4.5"/></svg>',
    fwd: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.34-5.66"/><path d="M20 4v4.5h-4.5"/></svg>',
    cc: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><rect x="3" y="5.5" width="18" height="13" rx="3"/><path d="M10.5 10.2a2.3 2.3 0 1 0 0 3.6M17 10.2a2.3 2.3 0 1 0 0 3.6" stroke-linecap="round"/></svg>',
    audio: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/></svg>',
    dock: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4.5" width="18" height="15" rx="2.5"/><path d="M14 9.5l-5 5M9 10v4.5h4.5"/></svg>',
  };

  // opts: { site, title, size, subsOn, isNetflix, bridge(cmd, arg), onSize(n), onSubs(on), onClose() }
  async function open(v, opts) {
    const ar = v.videoWidth && v.videoHeight ? v.videoWidth / v.videoHeight : 16 / 9;
    const width = Math.round(Math.min(640, Math.max(400, screen.availWidth * .3)));
    const win = await documentPictureInPicture.requestWindow({ width, height: Math.round(width / ar) });
    const d = win.document;
    d.title = opts.title || opts.site || 'pip.';
    const st = d.createElement('style'); st.textContent = CSS; d.head.appendChild(st);
    d.body.innerHTML = `
      <div id="stage"></div>
      <div id="subs"></div>
      <div id="flash"></div>
      <div id="ui">
        <div id="top"><span class="wm">pip<i></i></span><span id="ttl"></span></div>
        <div id="prog"><div id="fill"></div></div>
        <div id="bar">
          <button class="b" id="bPlay" title="Play / pause (Space)">${I.pause}</button>
          <button class="b wide" id="bBack" title="Back 10 s (←)">${I.back}<em>10</em></button>
          <button class="b wide" id="bFwd" title="Forward 10 s (→)">${I.fwd}<em>10</em></button>
          <span id="time"></span><span class="sp"></span>
          <button class="b" id="bCC" title="Subtitles (C)">${I.cc}</button>
          <button class="b" id="bAudio" title="Audio language">${I.audio}</button>
          <button class="b" id="bDock" title="Back to the tab">${I.dock}</button>
        </div>
        <div class="menu" id="mCC"></div>
        <div class="menu" id="mAudio"></div>
      </div>`;
    const $ = id => d.getElementById(id);
    $('ttl').textContent = opts.title || '';

    // move the site's video in, remember exactly where it was
    const home = { parent: v.parentNode, next: v.nextSibling, style: v.getAttribute('style'), controls: v.controls };
    const shown = [];   // text tracks we switched from "showing" to "hidden" (we draw them instead)
    $('stage').appendChild(v);
    v.controls = false;
    if (v.paused && !v.ended) v.play().catch(() => {});

    let size = opts.size || 100, subsOn = opts.subsOn !== false, closed = false;
    const applySize = () => { $('subs').style.setProperty('--s', size / 100); };
    applySize();
    $('subs').classList.toggle('off', !subsOn);

    // ---------- subtitles ----------
    let lastText = null;
    function capFromPage() {
      for (const sel of CAPTIONS) {
        const el = document.querySelector(sel);
        if (el) return (el.innerText || el.textContent || '').replace(/\r/g, '').replace(/\n{2,}/g, '\n').trim();
      }
      return null;
    }
    function capFromTracks() {
      let out = null;
      for (const t of v.textTracks || []) {
        if (t.kind !== 'subtitles' && t.kind !== 'captions') continue;
        if (t.mode === 'showing') { t.mode = 'hidden'; shown.push(t); }
        if (t.mode !== 'hidden' || !t.activeCues) continue;
        const txt = [...t.activeCues].map(c => (c.text || '').replace(/<[^>]+>/g, '')).join('\n').trim();
        out = (out ? out + '\n' : '') + txt;
      }
      return out;
    }
    function drawSubs() {
      const t = capFromPage() ?? capFromTracks() ?? '';
      if (t === lastText) return;
      lastText = t;
      $('subs').innerHTML = t ? t.split('\n').filter(Boolean).map(l => `<span>${esc(l)}</span>`).join('') : '';
    }

    // ---------- controls ----------
    let uiT = 0;
    const showUI = () => { d.body.classList.add('ui'); clearTimeout(uiT); uiT = setTimeout(() => { if (!d.querySelector('.menu.open')) d.body.classList.remove('ui'); }, 2600); };
    d.addEventListener('mousemove', showUI);
    d.addEventListener('mouseleave', () => { if (!d.querySelector('.menu.open')) d.body.classList.remove('ui'); });
    let flashT = 0;
    const flash = msg => { $('flash').textContent = msg; $('flash').classList.add('on'); clearTimeout(flashT); flashT = setTimeout(() => $('flash').classList.remove('on'), 900); };

    const playPause = () => { if (v.paused) v.play().catch(() => {}); else v.pause(); };
    const seek = async dlt => {
      if (opts.isNetflix) { await opts.bridge('seek', dlt); }   // Netflix errors out when currentTime is set from outside
      else v.currentTime = Math.max(0, Math.min((v.duration || 1e9) - .5, v.currentTime + dlt));
      flash((dlt > 0 ? '+' : '−') + Math.abs(dlt) + ' s');
    };
    $('bPlay').onclick = playPause;
    $('stage').onclick = () => { closeMenus(); playPause(); };
    $('bBack').onclick = () => seek(-10);
    $('bFwd').onclick = () => seek(10);
    $('bDock').onclick = () => win.close();
    $('prog').onclick = e => {
      if (!v.duration || !isFinite(v.duration)) return;
      const r = $('prog').getBoundingClientRect(), to = (e.clientX - r.left) / r.width * v.duration;
      seek(Math.round(to - v.currentTime));
    };

    function closeMenus() { d.querySelectorAll('.menu.open').forEach(m => m.classList.remove('open')); $('bCC').classList.remove('on'); $('bAudio').classList.remove('on'); }
    async function tracks() {
      if (opts.isNetflix) {
        const r = await opts.bridge('tracks');
        if (r && (r.text || []).length) return { ...r, api: true };
      }
      const text = [...(v.textTracks || [])].map((t, i) => ({ t, i })).filter(x => x.t.kind === 'subtitles' || x.t.kind === 'captions')
        .map(({ t, i }) => ({ id: 'tt' + i, label: t.label || t.language || 'Track ' + (i + 1), on: t.mode !== 'disabled' }));
      const audio = v.audioTracks ? [...v.audioTracks].map((t, i) => ({ id: 'at' + i, label: t.label || t.language || 'Audio ' + (i + 1), on: t.enabled })) : [];
      return { text, audio, api: false };
    }
    async function pickText(id) {
      if (id.startsWith('tt') || id === 'tt-off') {
        [...v.textTracks].forEach((t, i) => { if (t.kind === 'subtitles' || t.kind === 'captions') t.mode = id === 'tt' + i ? 'hidden' : 'disabled'; });
      } else await opts.bridge('text', id);
      lastText = null;
    }
    async function pickAudio(id) {
      if (id.startsWith('at')) [...v.audioTracks].forEach((t, i) => { t.enabled = id === 'at' + i; });
      else await opts.bridge('audio', id);
    }
    const sizeRow = () => `<h4>Size</h4><div class="row"><button class="b" data-sz="-10" title="Smaller (−)">A−</button><span id="szv">${size}%</span><button class="b" data-sz="10" title="Bigger (+)">A+</button></div>`;
    const item = (x, kind) => `<button class="it${x.on ? ' on' : ''}" data-${kind}="${esc(String(x.id))}">${esc(x.label)}</button>`;

    async function openCC() {
      const m = $('mCC');
      if (m.classList.contains('open')) return closeMenus();
      closeMenus();
      const t = await tracks();
      let h = `<h4>Subtitles</h4>`;
      if (t.text.length) {
        if (!t.api) h += item({ id: 'tt-off', label: 'Off', on: !t.text.some(x => x.on) }, 'text');
        h += t.text.map(x => item(x, 'text')).join('');
      } else h += `<p>Pick the language in the player's own menu on the tab. Whatever it shows appears here.</p>`;
      h += `<hr><button class="it${subsOn ? ' on' : ''}" data-show="1">Show subtitles here</button>` + sizeRow();
      m.innerHTML = h;
      m.classList.add('open'); $('bCC').classList.add('on'); showUI();
    }
    async function openAudio() {
      const m = $('mAudio');
      if (m.classList.contains('open')) return closeMenus();
      closeMenus();
      const t = await tracks();
      m.innerHTML = `<h4>Audio</h4>` + (t.audio.length ? t.audio.map(x => item(x, 'audio')).join('')
        : `<p>Pick the audio language in the player's own menu on the tab.</p>`);
      m.classList.add('open'); $('bAudio').classList.add('on'); showUI();
    }
    $('bCC').onclick = openCC;
    $('bAudio').onclick = openAudio;
    d.addEventListener('click', async e => {
      const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.text) { await pickText(b.dataset.text); closeMenus(); flash('SUBTITLES · ' + b.textContent.toUpperCase()); }
      else if (b.dataset.audio) { await pickAudio(b.dataset.audio); closeMenus(); flash('AUDIO · ' + b.textContent.toUpperCase()); }
      else if (b.dataset.show) { setSubs(!subsOn); b.classList.toggle('on', subsOn); }
      else if (b.dataset.sz) { setSize(size + +b.dataset.sz); }
    });
    function setSize(n) {
      size = Math.max(50, Math.min(250, n)); applySize();
      const sv = $('szv'); if (sv) sv.textContent = size + '%';
      opts.onSize && opts.onSize(size);
    }
    function setSubs(on) { subsOn = on; $('subs').classList.toggle('off', !on); opts.onSubs && opts.onSubs(on); flash(on ? 'SUBTITLES ON' : 'SUBTITLES OFF'); }
    d.addEventListener('keydown', e => {
      if (e.target.closest && e.target.closest('input')) return;
      const k = e.key;
      if (k === ' ' || k === 'k') { e.preventDefault(); playPause(); }
      else if (k === 'ArrowLeft') seek(-10);
      else if (k === 'ArrowRight') seek(10);
      else if (k === 'c' || k === 'C') setSubs(!subsOn);
      else if (k === '+' || k === '=') { setSize(size + 10); flash('SUBTITLES ' + size + '%'); }
      else if (k === '-') { setSize(size - 10); flash('SUBTITLES ' + size + '%'); }
      else if (k === 'Escape') closeMenus();
      showUI();
    });

    // ---------- tick: subtitles, time, play state ----------
    const tick = setInterval(() => {
      if (closed) return;
      drawSubs();
      $('bPlay').innerHTML = v.paused ? I.play : I.pause;
      const dur = isFinite(v.duration) ? v.duration : 0;
      $('time').textContent = dur ? `${tc(v.currentTime)} / ${tc(dur)}` : 'LIVE';
      $('fill').style.width = dur ? (v.currentTime / dur * 100) + '%' : '0';
      $('prog').style.visibility = dur ? '' : 'hidden';
    }, 120);
    showUI();

    // ---------- going back ----------
    function restore() {
      if (closed) return;
      closed = true;
      clearInterval(tick);
      shown.forEach(t => { try { t.mode = 'showing'; } catch {} });
      const p = home.parent;
      if (p && p.isConnected) p.insertBefore(v, home.next && home.next.parentNode === p ? home.next : null);
      else document.body.appendChild(v);
      if (home.style == null) v.removeAttribute('style'); else v.setAttribute('style', home.style);
      v.controls = home.controls;
      if (v.paused && !v.ended) v.play().catch(() => {});
      opts.onClose && opts.onClose();
    }
    win.addEventListener('pagehide', restore);

    return {
      win, v,
      close: () => { try { win.close(); } catch {} restore(); },
      setSize: n => { size = n; applySize(); const sv = $('szv'); if (sv) sv.textContent = size + '%'; },
      setSubs: on => { subsOn = on; $('subs').classList.toggle('off', !on); },
    };
  }

  window.__pipDoc = { open, CAPTIONS };
})();
